#include "Item.h"

void QUEUEinit();
 int QUEUEempty();
void QUEUEput(Item);
Item QUEUEget();
