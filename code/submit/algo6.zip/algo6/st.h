#ifndef ST_H
#define ST_H

#include "item.h"

void STinit(int);
void STinsert(Item);
Item STsearch(Key);
void STdelete(Item);

#endif
