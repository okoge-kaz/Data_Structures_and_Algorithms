#ifndef ITEM_H
#define ITEM_H

typedef char Item;

void print_item(Item);
int eq(Item, Item);

#endif